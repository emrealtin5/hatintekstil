<?php include 'header.php'; ?>

<main>
    <!-- Banner area start -->
    <section class="banner-3 banner-bg-3 overflow-hidden section-space">
        <div class="container">
            <div class="banner-3__shape-1 rr-downUp">
                <img src="assets/imgs/banner-3/shape-1.png" alt="image not found">
            </div>
            <div class="banner-3__shape-2 leftRight">
                <img src="assets/imgs/banner-3/shape-2.png" alt="image not found">
            </div>
            <div class="banner-3__shape-3" data-parallax='{"scale": 1.2, "smoothness": 15}'>
                <img src="assets/imgs/banner-3/bottom-shape.png" alt="image not found">
            </div>
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="banner-3__content">
                        <h6 class="banner-3__content-subtitle">Introducing Ribuild</h6>
                        <h1 class="banner-3__content-title">Building Excellence with Precision and Passion.</h1>
                        <a href="index-2.html" class="rr-btn">
                            <span class="btn-wrap">
                                <span class="text-one">Explore Service</span>
                                <span class="text-two">Explore Service</span>
                            </span>
                        </a>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="banner-3__from">
                        <h4>Need Construction Help?</h4>
                        <p>We are always here to help you at any time, </p>
                        <div class="row">
                            <div class="col-12">
                                <div class="banner-3__form-input">
                                    <input name="name" id="lname" type="text" placeholder="Full Name">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="banner-3__form-input">
                                    <input name="email" id="email" type="email" placeholder="Email Address">
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="banner-3__form-input-select d-flex flex-column">
                                    <select name="subject" id="subject" style="display: none;">
                                        <option value="">Categories</option>
                                        <option value="order">Categories-2</option>
                                        <option value="objection">Categories-3</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="banner-3__form-input">
                                    <div class="validation__wrapper-up position-relative">
                                        <textarea name="textarea" id="textarea" placeholder="Message"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <button type="submit" class="rr-btn">
                                    <span class="btn-wrap">
                                        <span class="text-one">Send Message</span>
                                        <span class="text-two">Send Message</span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Banner area end -->

    <!-- planning-execute area start -->
    <section class="planning-execute section-space overflow-hidden">
        <div class="container">
            <div class="row mb-minus-30">
                <div class="col-xl-3 col-md-6">
                    <div class="planning-execute__item mb-30 section-bg-2 d-flex align-items-center flex-column">
                        <span class="number">01</span>
                        <div class="planning-execute__item-img mb-25">
                            <img src="assets/imgs/planning-execute/planning-execute__item-1.png" alt="">
                        </div>
                        <h4 class="title mb-0 rr-fw-sbold">Financial Planning</h4>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="planning-execute__item mb-30 section-bg-2 d-flex align-items-center flex-column">
                        <span class="number">02</span>
                        <div class="planning-execute__item-img mb-25">
                            <img src="assets/imgs/planning-execute/planning-execute__item-2.png" alt="">
                        </div>
                        <h4 class="title mb-0 rr-fw-sbold">Architecture Design</h4>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="planning-execute__item mb-30 section-bg-2 d-flex align-items-center flex-column">
                        <span class="number">03</span>
                        <div class="planning-execute__item-img mb-25">
                            <img src="assets/imgs/planning-execute/planning-execute__item-3.png" alt="">
                        </div>
                        <h4 class="title mb-0 rr-fw-sbold">New Construction</h4>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="planning-execute__item mb-30 section-bg-2 d-flex align-items-center flex-column">
                        <span class="number">04</span>
                        <div class="planning-execute__item-img mb-25">
                            <img src="assets/imgs/planning-execute/planning-execute__item-4.png" alt="">
                        </div>
                        <h4 class="title mb-0 rr-fw-sbold">Building Renovation</h4>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- planning-execute area end -->

    <!-- mission area start -->
    <section class="mission section-space__bottom overflow-hidden">
        <div class="container rr-shape-p-c_1">
            <div class="mission-bg rr-shape-p-s_1 leftRight" data-background="assets/imgs/mission/bg.png"></div>
            <div class="row mb-60 mb-sm-40 mb-xs-35 align-items-center">
                <div class="col-lg-6">
                    <div class="section__title-wrapper text-center text-lg-start">
                        <span class="section__subtitle justify-content-start mb-13"><span data-width="40px" class="left-separetor"></span>Mission</span>
                        <h2 class="section__title title-animation text-capitalize mb-15 rr-br-hidden-md" data-cursor="-opaque">Transforming Visions
                            <br> Into Reality
                        </h2>
                        <p class="rr-br-hidden-md mb-0">Morbi dapibus sollicitudin urna, at interdum sem euismod quis. <br> Maec vitae est maximus, bibendum turpis non, luctus massa.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="d-flex justify-content-xl-end mt-xs-25 mt-sm-25 mt-md-25 mt-lg-25 justify-content-center pl-110 rr-pl-none-xl">
                        <div class="skill-one__progress">
                            <div class="skill-one__progress-single">
                                <h6 class="skill-one__progress-title mb-10">Work Ability</h6>
                                <div class="bar">
                                    <div class="count-text">75%</div>
                                    <div class="bar-inner count-bar counted" data-percent="75%"></div>
                                </div>
                            </div>

                            <div class="skill-one__progress-single">
                                <h6 class="skill-one__progress-title mb-10">Keep Up</h6>
                                <div class="bar">
                                    <div class="count-text">85%</div>
                                    <div class="bar-inner count-bar counted" data-percent="85%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="mission__video">
                        <div class="mission__video-bg" data-background="assets/imgs/mission/shape-1.png"></div>
                        <img src="assets/imgs/mission/mission-video.jpg" alt="image not found">
                        <a href="https://www.youtube.com/watch?v=mbwuj58UEPg" class="popup-video" data-effect="mfp-move-from-top vertical-middle" data-magnetic data-magnetic-distance="100" data-magnetic-attraction=".9" data-magnetic-zoom="1.1">
                            <div class="icon">
                                <svg width="23" height="28" viewBox="0 0 23 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M22.5 13.134C23.1667 13.5189 23.1667 14.4811 22.5 14.866L1.5 26.9904C0.833332 27.3753 0 26.8942 0 26.1244V1.87564C0 1.10584 0.833333 0.624719 1.5 1.00962L22.5 13.134Z" fill="var(--rr-theme-primary)" />
                                </svg>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- mission area end -->

    <div class="overflow-hidden"> <!--for shape animation-->
        <!-- service area start -->
        <section class="service section-space__top section-space__bottom-80 theme-bg-heading-primary">
            <div class="container rr-shape-p-c_1">
                <div class="service__shape-1 rr-shape-p-s_1 leftRight">
                    <div></div>
                </div>
                <div class="service__shape-2 rr-shape-p-s_1 rr-upDown">
                    <div></div>
                </div>
                <div class="row mb-60 mb-sm-40 mb-xs-35 align-items-lg-end align-items-center">
                    <div class="col-xl-6">
                        <div class="section__title-wrapper text-center text-xl-start">
                            <span class="section__subtitle justify-content-start mb-13"><span data-width="40px" class="left-separetor"></span>Services</span>
                            <h2 class="section__title color-white title-animation text-capitalize mb-0 rr-br-hidden-xl" data-cursor="-opaque">The Essence Of Building
                                <br> Construction Design
                            </h2>
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="d-flex flex-column justify-content-xl-end mt-xs-20 mt-sm-20 mt-md-20 mt-lg-20 pl-45 rr-mb-13-hide-xl rr-pl-none-lg justify-content-center text-center text-xl-start">
                            <p class="m-0 service__content-des rr-br-hidden-xl">At Ribuild, we are more than just a construction company. We are your
                                <br> partners in turning visions into reality, dedicated to delivering superior quality <br> and exceptional service every step of the way.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 image-reveal-hover-content">
                        <div class="service__list mb-minus-50" data-fx="8">
                            <a class="service__list-item d-flex align-items-center mb-50 block__title" data-img="assets/imgs/service/service-1.jpg">
                                <div class="number">01</div>
                                <div class="text d-flex flex-column">
                                    <span class="sub-t">Project Planning</span>
                                    <h4 class="color-white mb-0 title">Project Planning</h4>
                                </div>
                            </a>
                            <a class="service__list-item d-flex align-items-center mb-50 block__title" data-fx="8" data-img="assets/imgs/service/service-1.jpg">
                                <div class="number">02</div>
                                <div class="text d-flex flex-column">
                                    <span class="sub-t">Highest Standards</span>
                                    <h4 class="color-white mb-0 title">Industrial Structure</h4>
                                </div>
                            </a>
                            <a class="service__list-item d-flex align-items-center mb-50 block__title" data-fx="8" data-img="assets/imgs/service/service-1.jpg">
                                <div class="number">03</div>
                                <div class="text d-flex flex-column">
                                    <span class="sub-t">Project Design</span>
                                    <h4 class="color-white mb-0 title">Interior Design</h4>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- service area end -->

        <section class="service__what-we-do-3__text theme-bg-heading-primary">
            <h2>CONSTRUCTION</h2>
        </section>

        <!-- what-we-do-3 area start -->
        <section class="what-we-do-3 section-space__bottom section-space__top-80 theme-bg-heading-primary">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="what-we-do-3__media pr-15 rr-pr-none-xl rr-mb-60-md">
                            <img src="assets/imgs/what-we-do-3/what-we-do.jpg" alt="" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="pl-40 rr-pl-none-xl">
                            <div class="section__title-wrapper text-center text-lg-start mb-50 mb-sm-40 mb-xs-35">
                                <span class="section__subtitle justify-content-start mb-13"><span data-width="40px" class="left-separetor"></span>What We Do</span>
                                <h2 class="section__title title-animation color-white text-capitalize mb-15 rr-br-hidden-xl" data-cursor="-opaque">Upgrading Your Factory
                                    <br>
                                    Performance
                                </h2>
                                <p class="rr-br-hidden-xl what-we-do-3__content-p mb-0">Nulla et ipsum non justo congue consequat. Pellentesque accumsan ante
                                    <br> non ullamcorper imperdiet. Pellentque habitant morbi tristique senectus <br> netus malesuada fames turpis egestas.
                                </p>
                            </div>

                            <div class="what-we-do-3__list pr-40 rr-pr-none-xl">
                                <a href="project-details.html">Metal Engineering
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11.2287 0L2.15853 0C1.73187 0 1.38491 0.346892 1.38491 0.773475C1.38491 1.20006 1.73187 1.54695 2.15853 1.54695L9.35794 1.54695L0.226813 10.6786C-0.0756043 10.981 -0.0756043 11.4709 0.226813 11.7732C0.52923 12.0756 1.01919 12.0756 1.32161 11.7732L10.4527 2.64154V9.83954C10.4527 10.2661 10.7997 10.613 11.2264 10.613C11.653 10.613 12 10.2661 12 9.83954V0.773475C12.0023 0.346892 11.6554 0 11.2287 0Z" fill="#F44E19" />
                                    </svg>
                                </a>
                                <a href="project-details.html">Project Planning
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11.2287 0L2.15853 0C1.73187 0 1.38491 0.346892 1.38491 0.773475C1.38491 1.20006 1.73187 1.54695 2.15853 1.54695L9.35794 1.54695L0.226813 10.6786C-0.0756043 10.981 -0.0756043 11.4709 0.226813 11.7732C0.52923 12.0756 1.01919 12.0756 1.32161 11.7732L10.4527 2.64154V9.83954C10.4527 10.2661 10.7997 10.613 11.2264 10.613C11.653 10.613 12 10.2661 12 9.83954V0.773475C12.0023 0.346892 11.6554 0 11.2287 0Z" fill="#F44E19" />
                                    </svg>
                                </a>
                                <a href="project-details.html">Corporate Building
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11.2287 0L2.15853 0C1.73187 0 1.38491 0.346892 1.38491 0.773475C1.38491 1.20006 1.73187 1.54695 2.15853 1.54695L9.35794 1.54695L0.226813 10.6786C-0.0756043 10.981 -0.0756043 11.4709 0.226813 11.7732C0.52923 12.0756 1.01919 12.0756 1.32161 11.7732L10.4527 2.64154V9.83954C10.4527 10.2661 10.7997 10.613 11.2264 10.613C11.653 10.613 12 10.2661 12 9.83954V0.773475C12.0023 0.346892 11.6554 0 11.2287 0Z" fill="#F44E19" />
                                    </svg>
                                </a>
                                <a href="project-details.html">Budget Planning
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11.2287 0L2.15853 0C1.73187 0 1.38491 0.346892 1.38491 0.773475C1.38491 1.20006 1.73187 1.54695 2.15853 1.54695L9.35794 1.54695L0.226813 10.6786C-0.0756043 10.981 -0.0756043 11.4709 0.226813 11.7732C0.52923 12.0756 1.01919 12.0756 1.32161 11.7732L10.4527 2.64154V9.83954C10.4527 10.2661 10.7997 10.613 11.2264 10.613C11.653 10.613 12 10.2661 12 9.83954V0.773475C12.0023 0.346892 11.6554 0 11.2287 0Z" fill="#F44E19" />
                                    </svg>
                                </a>
                                <a href="project-details.html">Industrial Building
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11.2287 0L2.15853 0C1.73187 0 1.38491 0.346892 1.38491 0.773475C1.38491 1.20006 1.73187 1.54695 2.15853 1.54695L9.35794 1.54695L0.226813 10.6786C-0.0756043 10.981 -0.0756043 11.4709 0.226813 11.7732C0.52923 12.0756 1.01919 12.0756 1.32161 11.7732L10.4527 2.64154V9.83954C10.4527 10.2661 10.7997 10.613 11.2264 10.613C11.653 10.613 12 10.2661 12 9.83954V0.773475C12.0023 0.346892 11.6554 0 11.2287 0Z" fill="#F44E19" />
                                    </svg>
                                </a>
                                <a href="project-details.html">Interior Design
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11.2287 0L2.15853 0C1.73187 0 1.38491 0.346892 1.38491 0.773475C1.38491 1.20006 1.73187 1.54695 2.15853 1.54695L9.35794 1.54695L0.226813 10.6786C-0.0756043 10.981 -0.0756043 11.4709 0.226813 11.7732C0.52923 12.0756 1.01919 12.0756 1.32161 11.7732L10.4527 2.64154V9.83954C10.4527 10.2661 10.7997 10.613 11.2264 10.613C11.653 10.613 12 10.2661 12 9.83954V0.773475C12.0023 0.346892 11.6554 0 11.2287 0Z" fill="#F44E19" />
                                    </svg>
                                </a>
                                <a href="project-details.html">Metal Works
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11.2287 0L2.15853 0C1.73187 0 1.38491 0.346892 1.38491 0.773475C1.38491 1.20006 1.73187 1.54695 2.15853 1.54695L9.35794 1.54695L0.226813 10.6786C-0.0756043 10.981 -0.0756043 11.4709 0.226813 11.7732C0.52923 12.0756 1.01919 12.0756 1.32161 11.7732L10.4527 2.64154V9.83954C10.4527 10.2661 10.7997 10.613 11.2264 10.613C11.653 10.613 12 10.2661 12 9.83954V0.773475C12.0023 0.346892 11.6554 0 11.2287 0Z" fill="#F44E19" />
                                    </svg>
                                </a>
                                <a href="project-details.html">Successful Project
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M11.2287 0L2.15853 0C1.73187 0 1.38491 0.346892 1.38491 0.773475C1.38491 1.20006 1.73187 1.54695 2.15853 1.54695L9.35794 1.54695L0.226813 10.6786C-0.0756043 10.981 -0.0756043 11.4709 0.226813 11.7732C0.52923 12.0756 1.01919 12.0756 1.32161 11.7732L10.4527 2.64154V9.83954C10.4527 10.2661 10.7997 10.613 11.2264 10.613C11.653 10.613 12 10.2661 12 9.83954V0.773475C12.0023 0.346892 11.6554 0 11.2287 0Z" fill="#F44E19" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- what-we-do-3 area end -->
    </div>

    <!-- our-professional -->
    <section class="our-professional section-space">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section__title-wrapper text-center mb-60 mb-sm-40 mb-xs-35">
                        <span class="section__subtitle justify-content-center mb-13 ml-0"><span data-width="40px" class="left-separetor"></span>Our Professionals<span data-width="40px" class="right-separetor"></span></span>
                        <h2 class="section__title title-animation text-capitalize rr-br-hidden-md" data-cursor="-opaque">Experienced & Professional Team</h2>
                    </div>
                </div>
            </div>

            <div class="row mb-minus-30">
                <div class="col-xl-3 col-md-6">
                    <div class="our-professional__item mb-30">
                        <a href="team-details.html" class="our-professional__item-media d-block" data-cursor-text="View">
                            <img src="assets/imgs/our-professional/team-1.jpg" alt="image not found" class="img-fluid">
                        </a>

                        <div class="our-professional__item-socail d-flex flex-wrap flex-column">
                            <a href="https://www.instagram.com/"><img src="assets/imgs/our-professional/instagram.svg" alt=""></a>
                            <a href="#"><img src="assets/imgs/our-professional/linkedin.svg" alt=""></a>
                            <a href="https://dribbble.com/"><img src="assets/imgs/our-professional/twitter.svg" alt=""></a>
                            <a href="https://www.facebook.com/"><img src="assets/imgs/our-professional/facebook.svg" alt=""></a>
                        </div>
                        <div class="our-professional__item__content d-flex align-items-center justify-content-center text-center">

                            <div class="our-professional__item-text">
                                <h4 class="our-professional__item-title text-center rr-fw-bold  mb-0"><a href="team-details.html">Alex Jonsion</a></h4>
                                <span class="our-professional__item-subtitle text-center">CEO - Co Funder</span>
                            </div>
                        </div>
                        <div class="our-professional__item-to-plus">
                            <button>+</button>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="our-professional__item mb-30">
                        <a href="team-details.html" class="our-professional__item-media d-block" data-cursor-text="View">
                            <img src="assets/imgs/our-professional/team-2.jpg" alt="image not found" class="img-fluid">
                        </a>

                        <div class="our-professional__item-socail d-flex flex-wrap flex-column">
                            <a href="https://www.instagram.com/"><img src="assets/imgs/our-professional/instagram.svg" alt=""></a>
                            <a href="#"><img src="assets/imgs/our-professional/linkedin.svg" alt=""></a>
                            <a href="https://dribbble.com/"><img src="assets/imgs/our-professional/twitter.svg" alt=""></a>
                            <a href="https://www.facebook.com/"><img src="assets/imgs/our-professional/facebook.svg" alt=""></a>
                        </div>
                        <div class="our-professional__item__content d-flex align-items-center justify-content-center text-center">

                            <div class="our-professional__item-text">
                                <h4 class="our-professional__item-title text-center rr-fw-bold  mb-0"><a href="team-details.html">Eduard Nail</a></h4>
                                <span class="our-professional__item-subtitle text-center">Architect</span>
                            </div>
                        </div>
                        <div class="our-professional__item-to-plus">
                            <button>+</button>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="our-professional__item mb-30">
                        <a href="team-details.html" class="our-professional__item-media d-block" data-cursor-text="View">
                            <img src="assets/imgs/our-professional/team-3.jpg" alt="image not found" class="img-fluid">
                        </a>

                        <div class="our-professional__item-socail d-flex flex-wrap flex-column">
                            <a href="https://www.instagram.com/"><img src="assets/imgs/our-professional/instagram.svg" alt=""></a>
                            <a href="#"><img src="assets/imgs/our-professional/linkedin.svg" alt=""></a>
                            <a href="https://dribbble.com/"><img src="assets/imgs/our-professional/twitter.svg" alt=""></a>
                            <a href="https://www.facebook.com/"><img src="assets/imgs/our-professional/facebook.svg" alt=""></a>
                        </div>
                        <div class="our-professional__item__content d-flex align-items-center justify-content-center text-center">

                            <div class="our-professional__item-text">
                                <h4 class="our-professional__item-title text-center rr-fw-bold  mb-0"><a href="team-details.html">Jason Joy</a></h4>
                                <span class="our-professional__item-subtitle text-center">Contractor </span>
                            </div>
                        </div>
                        <div class="our-professional__item-to-plus">
                            <button>+</button>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="our-professional__item mb-30">
                        <a href="team-details.html" class="our-professional__item-media d-block" data-cursor-text="View">
                            <img src="assets/imgs/our-professional/team-4.jpg" alt="image not found" class="img-fluid">
                        </a>

                        <div class="our-professional__item-socail d-flex flex-wrap flex-column">
                            <a href="https://www.instagram.com/"><img src="assets/imgs/our-professional/instagram.svg" alt=""></a>
                            <a href="#"><img src="assets/imgs/our-professional/linkedin.svg" alt=""></a>
                            <a href="https://dribbble.com/"><img src="assets/imgs/our-professional/twitter.svg" alt=""></a>
                            <a href="https://www.facebook.com/"><img src="assets/imgs/our-professional/facebook.svg" alt=""></a>
                        </div>
                        <div class="our-professional__item__content d-flex align-items-center justify-content-center text-center">

                            <div class="our-professional__item-text">
                                <h4 class="our-professional__item-title text-center rr-fw-bold  mb-0"><a href="team-details.html">Laura Lepia</a></h4>
                                <span class="our-professional__item-subtitle text-center">Roof Designer</span>
                            </div>
                        </div>
                        <div class="our-professional__item-to-plus">
                            <button>+</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- our-professional -->

    <!-- support area start -->
    <section class="support section-space section-bg-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section__title-wrapper text-center text-lg-start">
                        <span class="section__subtitle justify-content-start mb-13"><span data-width="40px" class="left-separetor"></span>Support</span>
                        <h2 class="section__title title-animation text-capitalize mb-40 rr-br-hidden-xl" data-cursor="-opaque">Integrated Building Design <br>
                            For Enhanced Efficiency</h2>

                        <div class="support__list mb-minus-30">
                            <div class="support__list-item d-flex mb-30">
                                <div class="icon"><img src="assets/imgs/support/angle-right.svg" alt=""></div>
                                <div class="text">
                                    <p class="mb-0 rr-br-hidden-xl text-start">Vivamus eget tristique purus. Mauris rhoncus sem non lorem aliquet varius.
                                        <br> Aliquam non odio et arcu ullamcorper efficitur.
                                    </p>
                                </div>
                            </div>
                            <div class="support__list-item d-flex mb-30">
                                <div class="icon"><img src="assets/imgs/support/angle-right.svg" alt=""></div>
                                <div class="text">
                                    <p class="mb-0 rr-br-hidden-xl text-start">Suspendisse facilisis dolor id turpis varius malesuada. Morbi egestas libero
                                        <br> ac consectetur interdum uisque.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="pl-30 rr-pl-none-xl rr-mt-60-md">
                        <div class="rr__faq">
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item">
                                    <h5 class="accordion-header" id="headingOne">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            What Are The Charges of Renovation?
                                        </button>
                                    </h5>
                                    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>Our services are designed to help businesses leverage technology to streamline operation’s, improve efficiency.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h5 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                            What is Project Timing in Construction?
                                        </button>
                                    </h5>
                                    <div id="collapseTwo" class="accordion-collapse collapse show" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>Our services are designed to help businesses leverage technology to streamline operation’s, improve efficiency.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h5 class="accordion-header" id="headingThere">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThere" aria-expanded="true" aria-controls="collapseThere">
                                            How to contact our Support Team?
                                        </button>
                                    </h5>
                                    <div id="collapseThere" class="accordion-collapse collapse" aria-labelledby="headingThere" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>Our services are designed to help businesses leverage technology to streamline operation’s, improve efficiency.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h5 class="accordion-header" id="headingFour">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                                            How Are Construction Permits Obtained?
                                        </button>
                                    </h5>
                                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>Our services are designed to help businesses leverage technology to streamline operation’s, improve efficiency.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- support area end -->

    <!-- recent-works area start -->
    <section class="recent-works section-space overflow-hidden">
        <div class="container position-relative z-1 b-t__scroll-container"><!--data-target="b-t__scroll-container"-->
            <div class="big-text__scroll b-t__scroll" data-target=".b-t__scroll-container" data-target-height="-30">Recent Works</div>
            <div class="row">
                <div class="col-12">
                    <div class="section__title-wrapper text-center mb-60 mb-sm-40 mb-xs-35">
                        <span class="section__subtitle justify-content-center mb-13 ml-0"><span data-width="40px" class="left-separetor"></span>Recent Works<span data-width="40px" class="right-separetor"></span></span>
                        <h2 class="section__title title-animation text-capitalize rr-br-hidden-md" data-cursor="-opaque">Explore Our Best Recently
                            <br> Completed Projects
                        </h2>
                    </div>
                </div>
            </div>

            <div class="row align-items-center mb-minus-75">
                <div class="col-lg-7">
                    <div class="recent-works__item mb-75 mr-175 rr-mr-none-lg">
                        <a href="project-details.html" class="recent-works__item-media d-block" data-cursor-text="View" data-cursor="-r-p-white">
                            <img src="assets/imgs/recent-works/recent-works__item-1.jpg" alt="">
                        </a>
                        <div class="recent-works__item-text">
                            <h4 class="color-white"><a href="project-details.html">Construction Management</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="recent-works__item mb-75">
                        <a href="project-details.html" class="recent-works__item-media d-block" data-cursor-text="View" data-cursor="-r-p-white">
                            <img src="assets/imgs/recent-works/recent-works__item-2.jpg" alt="">
                        </a>
                        <div class="recent-works__item-text">
                            <h4 class="color-white"><a href="project-details.html">Construction Pro Solution</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="recent-works__item mb-75">
                        <a href="project-details.html" class="recent-works__item-media d-block" data-cursor-text="View" data-cursor="-r-p-white">
                            <img src="assets/imgs/recent-works/recent-works__item-3.jpg" alt="">
                        </a>
                        <div class="recent-works__item-text">
                            <h4 class="color-white"><a href="project-details.html">Renovation & Remodeling</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="recent-works__item mb-75 ml-175 rr-ml-none-lg">
                        <a href="project-details.html" class="recent-works__item-media d-block" data-cursor-text="View" data-cursor="-r-p-white">
                            <img src="assets/imgs/recent-works/recent-works__item-4.jpg" alt="">
                        </a>
                        <div class="recent-works__item-text">
                            <h4 class="color-white"><a href="project-details.html">General Construction</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- recent-works area end -->

    <!-- text-slider area start -->
    <section class="text-slider text-slider__section-space position-relative theme-bg-primary overflow-hidden">
        <div class="text-slider__slider carouselTicker carouselTicker-nav">
            <ul class="carouselTicker__list">
                <li>
                    <h3 data-cursor="-opaque" class="title">GREEN BUILDING</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">REMODELING</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">SERVICES</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">CONSTRUCTION</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">ARCHITECTURE</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">BLUEPRINT</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">INFRASTRUCTURE</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">GREEN BUILDING</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">REMODELING</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">SERVICES</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">CONSTRUCTION</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">ARCHITECTURE</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">BLUEPRINT</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">INFRASTRUCTURE</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">GREEN BUILDING</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">REMODELING</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">SERVICES</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">CONSTRUCTION</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">ARCHITECTURE</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">BLUEPRINT</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">INFRASTRUCTURE</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">GREEN BUILDING</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">REMODELING</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">SERVICES</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">CONSTRUCTION</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">ARCHITECTURE</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">BLUEPRINT</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
                <li>
                    <h3 data-cursor="-opaque" class="title">INFRASTRUCTURE</h3>
                </li>
                <li>
                    <h4 class="title bar">//</h4>
                </li>
            </ul>
        </div>
    </section>
    <!-- text-slider area end -->

    <div class="clients-testimonial theme-bg-heading-primary overflow-hidden section-space" data-background="assets/imgs/clients-testimonial/background.png">
        <div class="container">
            <div class="clients-testimonial__shape">
                <img src="assets/imgs/clients-testimonial/shape.png" alt="">
            </div>
            <div class="row">
                <div class="col-xl-6">
                    <div class="clients-testimonial__content">
                        <span class="section__subtitle justify-content-start mb-13"><span data-width="40px" class="left-separetor"></span>Clients Testimonials</span>
                        <h2 class="section__title title-animation text-white text-capitalize mb-15 rr-br-hidden-md" data-cursor="-opaque">What People Say About Our Company</h2>
                        <p>We are an architecture firm with a focus beautiful but functional design. At its heart, we believe in design is about usability and accessibility these are the guiding principles for our work.</p>
                    </div>
                </div>

                <div class="col-xl-6">
                    <div class="clients-testimonial__slider-wrapper position-relative">
                        <div class="swiper clients-testimonial__slider">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="clients-testimonial__item">
                                        <div class="clients-testimonial__rating">
                                            <img src="assets/imgs/clients-testimonial/star.png" alt="image not found">
                                            <img src="assets/imgs/clients-testimonial/star.png" alt="image not found">
                                            <img src="assets/imgs/clients-testimonial/star.png" alt="image not found">
                                            <img src="assets/imgs/clients-testimonial/star.png" alt="image not found">
                                            <img src="assets/imgs/clients-testimonial/star.png" alt="image not found">
                                        </div>

                                        <p class="mb-0">Effective testimonials go beyond a simple quote that proclaims your target greatness. They need to resonate with your target audience and the people who could also potentially benefit from the work you do in the future. The best testimonials tell a story with friction and resolution.</p>
                                        <div class="clients-testimonial__wrapper">
                                            <div class="clients-testimonial__author">
                                                <img src="assets/imgs/clients-testimonial/author.png" alt="image not found">
                                            </div>
                                            <div class="clients-testimonial__text">
                                                <h6>Jackin Martinez</h6>
                                                <span>UX/UI Designer</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clients-testimonial__slider__arrow">
                            <button class="clients-testimonial__slider__arrow-prev">
                                <svg width="18" height="12" viewBox="0 0 18 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M17 6L1 6" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M5.66667 11L1 6L5.66667 1" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </button>
                            <button class="clients-testimonial__slider__arrow-next">
                                <svg width="18" height="12" viewBox="0 0 18 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0.999999 6L17 6" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M12.3333 11L17 6L12.3333 1" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- pricing area start -->
    <section class="pricing section-space section-bg-1 overflow-hidden">
        <div class="container rr-shape-p-c_1">
            <div class="why-choose-us__shape d-none d-lg-block">
                <div class="pricing__shape-1 rr-shape-p-s_1 rr-upDown"><img src="assets/imgs/pricing/shape-1.png" alt="image not found"></div>
                <div class="pricing__shape-2 rr-shape-p-s_1 rr-downUp"><img src="assets/imgs/pricing/shape-2.png" alt="image not found"></div>
                <div class="pricing__shape-3 rr-shape-p-s_1 rr-upDown"><img src="assets/imgs/pricing/shape-3.png" alt="image not found"></div>
                <div class="pricing__shape-4 rr-shape-p-s_1 rr-upDown"><img src="assets/imgs/pricing/shape-4.png" alt="image not found"></div>
                <div class="pricing__shape-5 rr-shape-p-s_1 rr-downUp"><img src="assets/imgs/pricing/shape-5.png" alt="image not found"></div>
            </div>
            <div class="row mb-60 mb-sm-40 mb-xs-35 align-items-lg-end align-items-center">
                <div class="col-xl-6">
                    <div class="section__title-wrapper text-center text-xl-start">
                        <span class="section__subtitle justify-content-start mb-13"><span data-width="40px" class="left-separetor"></span>Pricing Plan</span>
                        <h2 class="section__title title-animation text-capitalize mb-0 rr-br-hidden-md" data-cursor="-opaque">Choose Right Pricing
                            <br> Plan For You
                        </h2>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="d-flex justify-content-xl-end mt-xs-25 mt-sm-25 mt-md-25 mt-lg-25 justify-content-center">
                        <div class="pricing__toggler_button mb-40 d-flex justify-content-center wow fadeIn animated" data-wow-delay=".5s">
                            <div class="pricing__shape-arrow-down rr-shape-p-s_1 rr-downUp"><img src="assets/imgs/pricing/arrow-down.png" alt="image not found"></div>
                            <button class="toggler active" id="monthly-btn">Monthly</button>
                            <div class="toggle">
                                <input type="checkbox" id="switcher" class="check">
                                <b class="b switch"></b>
                            </div>
                            <button class="toggler" id="yearly-btn">Yearly</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mb-minus-30">
                <div class="col-xl-4 col-md-6">
                    <div class="pricing__card overflow-hidden mb-30 wow clip-t-b" data-background="assets/imgs/pricing/bottom-shape.png">
                        <div class="pricing__card-image mb-40"><img src="assets/imgs/pricing/home.png" alt=""></div>
                        <h4 class="pricing__card-title rr-fw-sbold"><span>Basic</span></h4>
                        <div class="pricing__card-price mb-30 pb-30">
                            <h2 data-yearly='<span class="price">$199.<span>00</span></span>
                                <span class="month-year">PER YEARLY</span>' data-monthly='<span class="price">$99.<span>00</span></span>
                                <span class="month-year">PER MONTH</span>' class="d-flex flex-column">
                                <span class="price">$99.<span>00</span></span>
                                <span class="month-year">PER MONTH</span>
                            </h2>
                        </div>

                        <div class="pricing__card-body mb-40">
                            <ul>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Construction Hourly Rate
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Remodel Or Home Addition
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Limitless Concepts
                                </li>
                                <li class="not_included">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Architectural Plans
                                </li>
                                <li class="not_included">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Economic Market Survey
                                </li>
                            </ul>
                        </div>

                        <a href="index-2.html" class="rr-btn rr-btn__transparent">
                            <span class="btn-wrap">
                                <span class="text-one">Purchase Now</span>
                                <span class="text-two">Purchase Now</span>
                            </span>
                        </a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="pricing__card pricing__card-standard overflow-hidden mb-30 wow clip-t-b" data-background="assets/imgs/pricing/bottom-shape__white.png">
                        <div class="pricing__card-image mb-40"><img src="assets/imgs/pricing/home.png" alt=""></div>
                        <h4 class="pricing__card-title rr-fw-sbold"><span>Premium</span></h4>
                        <div class="pricing__card-price mb-30 pb-30">
                            <h2 data-yearly='<span class="price">$215.<span>00</span></span>
                                <span class="month-year">PER YEARLY</span>' data-monthly='<span class="price">$115.<span>00</span></span>
                                <span class="month-year">PER MONTH</span>' class="d-flex flex-column">
                                <span class="price">$115.<span>00</span></span>
                                <span class="month-year">PER MONTH</span>
                            </h2>
                        </div>

                        <div class="pricing__card-body mb-40">
                            <ul>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Construction Hourly Rate
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Remodel Or Home Addition
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Limitless Concepts
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Architectural Plans
                                </li>
                                <li class="not_included">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Economic Market Survey
                                </li>
                            </ul>
                        </div>

                        <a href="index-2.html" class="rr-btn">
                            <span class="btn-wrap">
                                <span class="text-one">Purchase Now</span>
                                <span class="text-two">Purchase Now</span>
                            </span>
                        </a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="pricing__card overflow-hidden mb-30 wow clip-t-b" data-background="assets/imgs/pricing/bottom-shape.png">
                        <div class="pricing__card-image mb-40"><img src="assets/imgs/pricing/home.png" alt=""></div>
                        <h4 class="pricing__card-title rr-fw-sbold"><span>Premium</span></h4>
                        <div class="pricing__card-price mb-30 pb-30">
                            <h2 data-yearly='<span class="price">$299.<span>00</span></span>
                                <span class="month-year">PER YEARLY</span>' data-monthly='<span class="price">$199.<span>00</span></span>
                                <span class="month-year">PER MONTH</span>' class="d-flex flex-column">
                                <span class="price">$199.<span>00</span></span>
                                <span class="month-year">PER MONTH</span>
                            </h2>
                        </div>

                        <div class="pricing__card-body mb-40">
                            <ul>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Construction Hourly Rate
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Remodel Or Home Addition
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Limitless Concepts
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Architectural Plans
                                </li>
                                <li>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="10" r="10" fill="#F44E19" />
                                        <path d="M15 7L8.125 13L5 10.2727" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Economic Market Survey
                                </li>
                            </ul>
                        </div>

                        <a href="index-2.html" class="rr-btn rr-btn__transparent">
                            <span class="btn-wrap">
                                <span class="text-one">Purchase Now</span>
                                <span class="text-two">Purchase Now</span>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- pricing area end -->

    <!-- blog-2 area start -->
    <section class="blog-2 section-space">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section__title-wrapper text-center mb-60 mb-sm-40 mb-xs-35">
                        <span class="section__subtitle justify-content-center mb-13 ml-0"><span data-width="40px" class="left-separetor"></span>Our Latest Blog<span data-width="40px" class="right-separetor"></span></span>
                        <h2 class="section__title title-animation text-capitalize rr-br-hidden-md" data-cursor="-opaque">Read Our Blog & Post</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="swiper blog-2__slider">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="blog-2__item d-flex flex-column flex-sm-row">
                                    <div class="blog-2__item-text d-flex justify-content-center flex-column">
                                        <div class="blog-2__item-meta mb-10">
                                            <a href="blog-details.html">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14 14.9999V13.4444C14 12.6192 13.6576 11.8279 13.0481 11.2445C12.4386 10.661 11.612 10.3333 10.75 10.3333H4.25C3.38805 10.3333 2.5614 10.661 1.9519 11.2445C1.34241 11.8279 1 12.6192 1 13.4444V14.9999" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M7.5 7.22222C9.29493 7.22222 10.75 5.82933 10.75 4.11111C10.75 2.39289 9.29493 1 7.5 1C5.70507 1 4.25 2.39289 4.25 4.11111C4.25 5.82933 5.70507 7.22222 7.5 7.22222Z" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                                By Admin</a>
                                            <a href="blog-details.html">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.5556 2.3999H2.44444C1.6467 2.3999 1 3.0267 1 3.7999V13.5999C1 14.3731 1.6467 14.9999 2.44444 14.9999H12.5556C13.3533 14.9999 14 14.3731 14 13.5999V3.7999C14 3.0267 13.3533 2.3999 12.5556 2.3999Z" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M10.3887 1V3.8" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M4.61133 1V3.8" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M1 6.6001H14" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                                26 January, 2024</a>
                                        </div>

                                        <h4 class="blog-2__item-title mb-15 mb-xs-10 rr-fw-bold text-capitalize"><a href="blog-details.html">Construction Begins On New Office Building.</a></h4>

                                        <p class="mb-20">Blandit cursus risus at ultrices. Aliquam malesuada bibendum arcu vitae curabitur tristique senectu netus.</p>

                                        <a class="blog-2__item-readmore" href="blog-details.html">Read More
                                            <svg width="20" height="11" viewBox="0 0 20 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1 5.5L19 5.5" stroke="#6A6A6A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M13.75 1L19 5.5L13.75 10" stroke="#6A6A6A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                    <a href="blog-details.html" data-cursor-text="View" class="blog-2__item-media d-block">
                                        <img src="assets/imgs/blog-2/blog-1.jpg" alt="image not found" class="img-fluid">
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="blog-2__item d-flex flex-column flex-sm-row">
                                    <div class="blog-2__item-text d-flex justify-content-center flex-column">
                                        <div class="blog-2__item-meta mb-10">
                                            <a href="blog-details.html">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14 14.9999V13.4444C14 12.6192 13.6576 11.8279 13.0481 11.2445C12.4386 10.661 11.612 10.3333 10.75 10.3333H4.25C3.38805 10.3333 2.5614 10.661 1.9519 11.2445C1.34241 11.8279 1 12.6192 1 13.4444V14.9999" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M7.5 7.22222C9.29493 7.22222 10.75 5.82933 10.75 4.11111C10.75 2.39289 9.29493 1 7.5 1C5.70507 1 4.25 2.39289 4.25 4.11111C4.25 5.82933 5.70507 7.22222 7.5 7.22222Z" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                                By Admin</a>
                                            <a href="blog-details.html">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.5556 2.3999H2.44444C1.6467 2.3999 1 3.0267 1 3.7999V13.5999C1 14.3731 1.6467 14.9999 2.44444 14.9999H12.5556C13.3533 14.9999 14 14.3731 14 13.5999V3.7999C14 3.0267 13.3533 2.3999 12.5556 2.3999Z" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M10.3887 1V3.8" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M4.61133 1V3.8" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M1 6.6001H14" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                                26 January, 2024</a>
                                        </div>

                                        <h4 class="blog-2__item-title mb-15 mb-xs-10 rr-fw-bold text-capitalize"><a href="blog-details.html">Safety Essential Protocols for Construction Sites.</a></h4>

                                        <p class="mb-20">Blandit cursus risus at ultrices. Aliquam malesuada bibendum arcu vitae curabitur tristique senectu netus.</p>

                                        <a class="blog-2__item-readmore" href="blog-details.html">Read More
                                            <svg width="20" height="11" viewBox="0 0 20 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1 5.5L19 5.5" stroke="#6A6A6A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M13.75 1L19 5.5L13.75 10" stroke="#6A6A6A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                    <a href="blog-details.html" data-cursor-text="View" class="blog-2__item-media d-block">
                                        <img src="assets/imgs/blog-2/blog-2.jpg" alt="image not found" class="img-fluid">
                                    </a>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="blog-2__item d-flex flex-column flex-sm-row">
                                    <div class="blog-2__item-text d-flex justify-content-center flex-column">
                                        <div class="blog-2__item-meta mb-10">
                                            <a href="blog-details.html">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M14 14.9999V13.4444C14 12.6192 13.6576 11.8279 13.0481 11.2445C12.4386 10.661 11.612 10.3333 10.75 10.3333H4.25C3.38805 10.3333 2.5614 10.661 1.9519 11.2445C1.34241 11.8279 1 12.6192 1 13.4444V14.9999" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M7.5 7.22222C9.29493 7.22222 10.75 5.82933 10.75 4.11111C10.75 2.39289 9.29493 1 7.5 1C5.70507 1 4.25 2.39289 4.25 4.11111C4.25 5.82933 5.70507 7.22222 7.5 7.22222Z" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                                By Admin</a>
                                            <a href="blog-details.html">
                                                <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12.5556 2.3999H2.44444C1.6467 2.3999 1 3.0267 1 3.7999V13.5999C1 14.3731 1.6467 14.9999 2.44444 14.9999H12.5556C13.3533 14.9999 14 14.3731 14 13.5999V3.7999C14 3.0267 13.3533 2.3999 12.5556 2.3999Z" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M10.3887 1V3.8" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M4.61133 1V3.8" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M1 6.6001H14" stroke="#F44E19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                                26 January, 2024</a>
                                        </div>

                                        <h4 class="blog-2__item-title mb-15 mb-xs-10 rr-fw-bold text-capitalize"><a href="blog-details.html">Construction Begins On New Office Building.</a></h4>

                                        <p class="mb-20">Blandit cursus risus at ultrices. Aliquam malesuada bibendum arcu vitae curabitur tristique senectu netus.</p>

                                        <a class="blog-2__item-readmore" href="blog-details.html">Read More
                                            <svg width="20" height="11" viewBox="0 0 20 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M1 5.5L19 5.5" stroke="#6A6A6A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M13.75 1L19 5.5L13.75 10" stroke="#6A6A6A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                    </div>
                                    <a href="blog-details.html" data-cursor-text="View" class="blog-2__item-media d-block">
                                        <img src="assets/imgs/blog-2/blog-1.jpg" alt="image not found" class="img-fluid">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="blog-2__slider-dot mt-60 mt-md-40 mt-sm-35 mt-xs-30"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- blog-2 area end -->

    <!-- cta-3 area start -->
    <section class="cta-3 cta-3__footer-up overflow-hidden">
        <div class="cta-3__bg-color"></div>
        <div class="container rr-shape-p-c_1">
            <div class="cta-3__shape-1 rr-shape-p-s_1 leftRight"><img src="assets/imgs/cta-3/shape-1.png" alt="image not found"></div>
            <div class="row">
                <div class="col-12">
                    <div class="cta-3__content d-flex flex-column flex-lg-row align-items-center justify-content-between theme-bg-heading-primary overflow-hidden">
                        <div class="cta-3__content-bg" data-background="assets/imgs/cta-3/bg.jpg"></div>
                        <div class="cta-3__content-text">
                            <h2 class="cta-3__content-title color-white">Ready to Build Your <br> Dream Space?</h2>
                        </div>

                        <a href="contact.php" class="rr-btn">
                            <span class="btn-wrap">
                                <span class="text-one">Start Your Free Quote</span>
                                <span class="text-two">Start Your Free Quote</span>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- cta-3 area end -->

</main>
<!-- Footer area start -->
<footer>
    <section class="footer-3__area-common section-bg-1 overflow-hidden">
        <div class="container rr-shape-p-c_1">
            <div class="footer-3__shape-1 rr-shape-p-s_1 leftRight"><img src="assets/imgs/footer-3/shape-1.png" alt="image not found"></div>
            <div class="footer-3__shape-2 rr-shape-p-s_1 upDown"><img src="assets/imgs/footer-3/shape-2.png" alt="image not found"></div>
            <div class="footer-3__main-wrapper">
                <div class="row mb-minus-50">
                    <div class="col-lg-3 col-6">
                        <div class="footer-3__widget footer-3__widget-item-1">
                            <div class="footer-3__logo mb-35">
                                <a href="index-2.html">
                                    <img class="img-fluid" src="assets/imgs/logo/logo.svg" alt="logo not found">
                                </a>
                            </div>

                            <div class="footer-3__content mb-30 mb-xs-25">
                                <p class="mb-0">Quickly supply alternative strategic theme areas vis-a-vis B2C mindshare. Objectively repurpose stand-alone synergy via user-centric architectures.</p>
                            </div>

                            <div class="footer-3__numbers">
                                <h6 class="title mb-10">Phone Number:</h6>
                                <p class="mb-0"><a href="tel:121551579266">+121 551 579 266</a> / <a href="tel:851555961658">+85 155 596 1658</a></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="footer-3__widget footer-3__widget-item-2">
                            <div class="footer-3__widget-title">
                                <h4>Quick Links</h4>
                            </div>
                            <div class="footer-3__link">
                                <ul>
                                    <li><a href="about-us.html">About Us</a></li>
                                    <li><a href="team.html">Our Team</a></li>
                                    <li><a href="team-details.html">Testimonials</a></li>
                                    <li><a href="blog.html">Blog Grid</a></li>
                                    <li><a href="project.html">Projects</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="footer-3__widget footer-3__widget-item-3">
                            <div class="footer-3__widget-title">
                                <h4>Our Service</h4>
                            </div>

                            <div class="footer-3__link">
                                <ul>
                                    <li><a href="service-details.html">General Construction</a></li>
                                    <li><a href="service-details.html">Property Maintenance</a></li>
                                    <li><a href="service-details.html">Project Managment</a></li>
                                    <li><a href="service-details.html">Virtual Design & Build</a></li>
                                    <li><a href="service-details.html">Preconstruction</a></li>
                                    <li><a href="service-details.html">Terms of use</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="footer-3__widget footer-3__widget-item-4">
                            <div class="footer-3__widget-title">
                                <h4>Newsletter</h4>
                            </div>

                            <div class="footer-3__content mb-15">
                                <p class="mb-0 rr-br-hidden-lg">Corporate business typically <br> refers to large-scale mansola it.</p>
                            </div>

                            <div class="footer-3__widget-subscribe mb-25">
                                <input type="text" placeholder="Enter Your Email">
                                <button type="submit" class="rr-btn">
                                    <span class="btn-wrap">
                                        <span class="text-one">
                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M14.75 1.21875C15.8125 0.59375 17.1562 1.5 16.9688 2.75L15.125 14.8438C15.0312 15.3125 14.7812 15.6875 14.375 15.9375C14.125 16.0625 13.875 16.125 13.625 16.125C13.4375 16.125 13.25 16.0938 13.0625 16L9.5625 14.5625L8.1875 16.4062C7.34375 17.5625 5.5 16.9688 5.5 15.5V12.875L1.90625 11.4062C0.75 10.9375 0.65625 9.34375 1.75 8.71875L14.75 1.21875ZM7 15.5L8.125 13.9688L7 13.5V15.5ZM13.625 14.625L15.5 2.5L2.5 10L5.84375 11.4062L12.4688 5.65625C12.9062 5.25 13.5312 5.8125 13.2188 6.3125L8.8125 12.625L13.625 14.625Z" fill="white" />
                                            </svg>
                                        </span>
                                        <span class="text-two">
                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M14.75 1.21875C15.8125 0.59375 17.1562 1.5 16.9688 2.75L15.125 14.8438C15.0312 15.3125 14.7812 15.6875 14.375 15.9375C14.125 16.0625 13.875 16.125 13.625 16.125C13.4375 16.125 13.25 16.0938 13.0625 16L9.5625 14.5625L8.1875 16.4062C7.34375 17.5625 5.5 16.9688 5.5 15.5V12.875L1.90625 11.4062C0.75 10.9375 0.65625 9.34375 1.75 8.71875L14.75 1.21875ZM7 15.5L8.125 13.9688L7 13.5V15.5ZM13.625 14.625L15.5 2.5L2.5 10L5.84375 11.4062L12.4688 5.65625C12.9062 5.25 13.5312 5.8125 13.2188 6.3125L8.8125 12.625L13.625 14.625Z" fill="white" />
                                            </svg>
                                        </span>
                                    </span>
                                </button>
                            </div>

                            <div class="footer-3__social-wrapper">
                                <h6 class="social-title mb-10">Follow Us:</h6>
                                <div class="footer-3__social">
                                    <a href="https://www.facebook.com/">
                                        <svg width="10" height="18" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M9 1H6.81818C5.85376 1 4.92884 1.42143 4.24688 2.17157C3.56493 2.92172 3.18182 3.93913 3.18182 5V7.4H1V10.6H3.18182V17H6.09091V10.6H8.27273L9 7.4H6.09091V5C6.09091 4.78783 6.16753 4.58434 6.30392 4.43431C6.44031 4.28429 6.6253 4.2 6.81818 4.2H9V1Z" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                    <a href="https://x.com/">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M9.11264 7.06225L15.0379 15.5H15.0341L14.4746 14.7169L9.1919 7.32307L9.19189 7.32306L8.55899 6.43729L8.55898 6.43727L4.49503 0.749074L4.34547 0.539738H4.0882H1.92015H0.989979L0.962074 0.5H4.50452L8.48597 6.1699L8.85112 6.6899L8.85114 6.68987L9.11264 7.06225ZM11.4929 15.2982L11.637 15.5H11.4955L7.2824 9.50047L6.91725 8.98049L6.49771 9.45768L1.18538 15.5H1.1054L6.62206 9.22562L6.88187 8.93013L6.65575 8.60813L3.37261 3.93275L6.54913 8.37872L6.54914 8.37873L7.08887 9.13411V9.13445L7.18204 9.26486L11.4929 15.2982ZM14.3732 0.5L9.296 6.27491H9.21598L9.27067 6.2127L14.2932 0.5H14.3732Z" stroke="#15181B" />
                                        </svg>
                                    </a>
                                    <a href="https://www.linkedin.com/">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12.1999 6.05273C13.4729 6.05273 14.6938 6.58506 15.594 7.53262C16.4942 8.48017 16.9999 9.76532 16.9999 11.1054V17.0001H13.7999V11.1054C13.7999 10.6587 13.6313 10.2303 13.3313 9.91445C13.0312 9.5986 12.6242 9.42116 12.1999 9.42116C11.7756 9.42116 11.3686 9.5986 11.0685 9.91445C10.7685 10.2303 10.5999 10.6587 10.5999 11.1054V17.0001H7.3999V11.1054C7.3999 9.76532 7.90562 8.48017 8.80579 7.53262C9.70596 6.58506 10.9269 6.05273 12.1999 6.05273Z" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M4.2 6.89502H1V17.0003H4.2V6.89502Z" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M2.6 4.36842C3.48366 4.36842 4.2 3.61437 4.2 2.68421C4.2 1.75405 3.48366 1 2.6 1C1.71634 1 1 1.75405 1 2.68421C1 3.61437 1.71634 4.36842 2.6 4.36842Z" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                    <a href="https://www.instagram.com/">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M13 1H5C2.79086 1 1 2.79086 1 5V13C1 15.2091 2.79086 17 5 17H13C15.2091 17 17 15.2091 17 13V5C17 2.79086 15.2091 1 13 1Z" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M12.1999 8.49575C12.2986 9.16155 12.1849 9.84153 11.8749 10.439C11.5649 11.0364 11.0744 11.5209 10.4732 11.8235C9.87195 12.1261 9.19062 12.2314 8.52609 12.1245C7.86156 12.0176 7.24767 11.7038 6.77173 11.2279C6.2958 10.7519 5.98205 10.1381 5.87512 9.47352C5.76819 8.80899 5.87352 8.12767 6.17612 7.52645C6.47873 6.92524 6.96321 6.43475 7.56065 6.12475C8.15809 5.81475 8.83807 5.70102 9.50386 5.79975C10.183 5.90046 10.8117 6.21692 11.2972 6.7024C11.7827 7.18787 12.0992 7.81661 12.1999 8.49575Z" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            <path d="M13.3999 4.6001H13.4079" stroke="#15181B" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="footer-3__truck-wrapper">
                        <img class="footer-3__truck movingX" src="assets/imgs/footer-3/track.png" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-3__bottom-wrapper position-relative z-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="footer-3__copyright text-lg-start text-center">
                            <p class="mb-0">© Copyright <a href="index-2.html">Ribuild</a> 2024 . All right reserved.</p>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="footer-3__copyright-menu">
                            <ul>
                                <li><a href="about-us.html">Privacy Policy</a></li>
                                <li><a href="contact.php">Terms & Conditions</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</footer>
<!-- Footer area end -->

<!-- JS here -->
<script src="assets/js/vendor/jquery-3.7.1.min.js"></script>
<script src="assets/js/plugins/waypoints.min.js"></script>
<script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
<script src="assets/js/plugins/meanmenu.min.js"></script>
<script src="assets/js/plugins/odometer.min.js"></script>
<script src="assets/js/plugins/swiper.min.js"></script>
<script src="assets/js/plugins/wow.js"></script>
<script src="assets/js/vendor/magnific-popup.min.js"></script>
<script src="assets/js/vendor/type.js"></script>
<script src="assets/js/plugins/nice-select.min.js"></script>
<script src="assets/js/vendor/jquery-ui.min.js"></script>
<script src="assets/js/vendor/jquery.appear.js"></script>
<script src="assets/js/plugins/parallax.min.js"></script>
<script src="assets/js/plugins/parallax-scroll.js"></script>
<script src="assets/js/plugins/isotope.pkgd.min.js"></script>
<script src="assets/js/plugins/imagesloaded.pkgd.min.js"></script>
<script src="assets/js/plugins/gsap.min.js"></script>
<script src="assets/js/plugins/ScrollTrigger.min.js"></script>
<script src="assets/js/plugins/SplitText.js"></script>
<script src="assets/js/plugins/tween-max.min.js"></script>
<script src="assets/js/plugins/draggable.min.js"></script>
<script src="assets/js/plugins/jquery.carouselTicker.js"></script>
<script src="assets/js/vendor/ajax-form.js"></script>
<script src="assets/js/plugins/TextPlugin.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/plugins/magiccursor.js"></script>
<script src="assets/js/image-reveal-hover.js"></script>
</body>


<!-- Mirrored from html.rrdevs.net/ribuild/index-3.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 02 Jan 2025 23:28:17 GMT -->

</html>